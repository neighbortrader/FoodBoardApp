package com.github.neighbortrader.foodboardapp.ui.offerDetail;

import android.app.Activity;

public class OfferDetailActivity extends Activity {
}

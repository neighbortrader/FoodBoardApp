package com.github.neighbortrader.foodboardapp.handler.requestsHandler;

public enum RequestTyps {
    POST_NEW_OFFER, GET_ALL_OFFERS, GET_ALL_CATEGORIES, GET_JWT_TOKEN, POST_NEW_USER
}

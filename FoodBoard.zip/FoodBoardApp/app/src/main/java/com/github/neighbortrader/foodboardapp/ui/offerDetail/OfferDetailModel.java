package com.github.neighbortrader.foodboardapp.ui.offerDetail;

public class OfferDetailModel {
}

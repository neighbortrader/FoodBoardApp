# FoodBoardApp

## How to build the project

### Required Android-Studio-Plugins to build the project:
1. Lombok
  
### Suquested Android-Studio-Plugins:
1. Fabric
  
### How to install Plugins in Android-Studio:

1) Launch Android Studio application

2) Choose File -> Settings 

3) Search for Plugins


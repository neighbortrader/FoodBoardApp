package com.github.neighbortrader.foodboardapp.ui.signUp;

import android.app.Activity;

public class SignUpActivity extends Activity {
}

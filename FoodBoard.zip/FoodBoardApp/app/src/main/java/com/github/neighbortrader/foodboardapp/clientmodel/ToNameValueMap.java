package com.github.neighbortrader.foodboardapp.clientmodel;

import java.util.Map;

public interface ToNameValueMap {
    Map<String, String> toNameValueMap();
}

package com.github.neighbortrader.foodboardapp.ui.signUp;

public class SignUpController {
}

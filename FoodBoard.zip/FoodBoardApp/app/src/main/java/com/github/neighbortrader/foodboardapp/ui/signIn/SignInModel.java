package com.github.neighbortrader.foodboardapp.ui.signIn;

public class SignInModel {
}

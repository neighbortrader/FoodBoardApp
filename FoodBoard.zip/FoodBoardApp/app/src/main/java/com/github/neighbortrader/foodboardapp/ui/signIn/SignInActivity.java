package com.github.neighbortrader.foodboardapp.ui.signIn;

import android.app.Activity;

public class SignInActivity extends Activity {
}
